import React , {Component} from 'react';
import { Card, Icon, Form, Select, Input, Button, message} from 'antd';
import PermissionTable from './PermisssionTable';
import PermissionModal from './PermissionModal';
import styles from './RoleManage.less';
import TableLayout from '../../layouts/TableLayout';
import axios from 'axios';

const FormItem = Form.Item;

@Form.create()
class MenuEditForm extends Component{

  constructor(props) {
    super(props);
    this.id = this.props.match.params.id;
    this.state = {
      editItem:undefined,
      permissionModalVisible: false,
      permissionModalDataSource: [],
      permissionTableDataSource: [],
      permissionTableSelectedRowKeys: [],
    }
  }

  //获取待编辑的角色的信息
  fetchItemInfo =() => {
    return axios.get(`/iam-ext/v1/roles/queryWithPermissionsAndLabels/${this.id}`);
  }

  //获取所有权限记录
  fetchAllPermissions = () => {
    return axios.get(`/iam-ext/v1/permissions/getAllPermissions`);
  }

  componentDidMount(){
    const _this = this;
    axios.all([this.fetchAllPermissions(), this.fetchItemInfo()])
      .then(axios.spread(function (perms, item) {
        // 两个请求现在都执行完成
        const permissionModalDataSource = perms.data;
        const editItem = item.data;

        const permissionTableDataSource = editItem.permissions;
        const permissionTableSelectedRowKeys = editItem.permissions.map(item => item.id);

        _this.setState({
          editItem,
          permissionModalDataSource,
          permissionTableDataSource,
          permissionTableSelectedRowKeys,
        });
      })).catch(err => {
      console.log(err);
      message.error('请求失败');
    });
  }

  //角色名称唯一性验证
  handleNameUniqueCheck = (rule,value,callback) => {
    if(!value || value === this.state.editItem.name){
      callback();
    }else{
      axios.get(`/iam-ext/v1/roles/nameCheck`,{
        params:{
          name:value,
        }
      }).then(res => {
        if(res.data === false){
          callback('角色名称已存在');
        }else{
          callback();
        }
      }).catch(err => {
        console.log('角色名称校验失败',err);
      });
    }
  }

//角色编码唯一性验证
  handleCodeUniqueCheck = (rule, value, callback) => {
    if(!value || value === this.state.editItem.code){
      callback();
    }else{
      axios.get(`/iam-ext/v1/roles/codeCheck`,{
        params:{
          code:value,
        }
      }).then(res => {
        if(res.data === false){
          callback('角色编码已存在');
        }else{
          callback();
        }
      }).catch(err => {
        console.log('角色编码校验失败',err);
      });
    }
  }

  //显示添加权限模态框
  handleShowModal =() => {
    this.setState({permissionModalVisible:true});
  }

  //隐藏添加权限模态框
  handleHideModal = () => {
    this.setState({permissionModalVisible:false});
  }

  //处理已分配权限列表 复选框改变事件
  handleSelectedKeysChange = (selectedRowKeys) => {
    this.handleAddPermission(selectedRowKeys);
  }

  //确认添加权限按钮
  handleAddPermission = (selectedRowKeys) => {
    const {permissionModalDataSource } = this.state;
    const permissionTableDataSource = permissionModalDataSource.filter(item => selectedRowKeys.indexOf(item.id) !== -1);
    this.setState({
      permissionTableDataSource,
      permissionTableSelectedRowKeys:selectedRowKeys,
      permissionModalVisible:false});
  }

  //确定按钮点击事件
  handleConfirmUpdate = (e) =>{
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {

        const permissions = [];
        values.permissionList.selectedRowKeys.map(item => {
          permissions.push({
            id:item,
          })
        });
        values.permissions = permissions;
        const { editItem } = this.state;
        if(values.name === editItem.name && values.code === editItem.code
           && this.hasSamePermissions(values,editItem)){
          message.info('没有改动，无需更新');
          return ;
        }

        axios.post(`/iam-ext/v1/roles/updateRoleObject/${editItem.id}`,{
          name:values.name,
          code:values.code,
          level:editItem.level,
          permissions:permissions,
        }).then(res => {
          if(res.data === true){
            message.success('更新成功!');
          }else{
            message.error(res.data);
          }
        }).catch(err => {
          message.error('请求失败，请重试');
          console.log(err);
        })
      }
    });
  }

  hasSamePermissions = (values,editItem) => {
    if(values.permissions.length === editItem.permissions.length){
        let ids = [];
        values.permissions.map(item => {
          ids.push(item.id);
        })
        editItem.permissions.map(item => {
          if(ids.indexOf(item.id) === -1){
            return false;
          }
        });
        return true;
    }else{
      return false;
    }
  }

  render(){
    const { getFieldDecorator } = this.props.form;
    const { permissionTableDataSource, permissionTableSelectedRowKeys,editItem } = this.state;
    const formItemLayout = {
      labelCol: { xs: { span: 24 }, sm: { span: 3 }, },
      wrapperCol: { xs: { span: 24 }, sm: { span: 12, }, },
    };
    return (
      <TableLayout title={`修改角色“ ${editItem && editItem.name}”`} showBackBtn={true}
                   onBackBtnClick={this.props.history.goBack}>
          <div>
            <Form>
              <FormItem label="角色名称" {...formItemLayout}>
                {getFieldDecorator(`name`, {
                  initialValue:editItem && editItem.name,
                  rules: [
                    {required: true, message: '角色名称不能为空', },
                    {max:64,message:'角色名称长度超过限制'},
                    {validator:this.handleNameUniqueCheck},
                  ],
                })(
                  <Input placeholder="角色名称（唯一）" autoComplete='off'/>
                )}
              </FormItem>
              <FormItem label="角色编码" {...formItemLayout}>
                {getFieldDecorator(`code`, {
                  initialValue:editItem && editItem.code,
                  // rules: [
                  //   {required: true, message: '角色编码不能为空', },
                  //   {max:128,message:'角色编码长度超过限制'},
                  //   {pattern:/^[a-z]([-a-z0-9]*[a-z0-9])$/,
                  //     message:'角色编码只能包含小写字母、数字或符号 "-",且以小写字母开头，不能以"-"结尾'},
                  //   {validator:this.handleCodeUniqueCheck},
                  // ],
                })(
                  <Input placeholder="角色编码（唯一）" autoComplete='off' disabled={true}/>
                )}
              </FormItem>
              <FormItem label="已分配权限" {...formItemLayout}>
                {getFieldDecorator('permissionList', {
                  initialValue: { dataSource:permissionTableDataSource,selectedRowKeys:permissionTableSelectedRowKeys },
                  rules:[]
                })(<PermissionTable showAddModal={this.handleShowModal}
                                    handleSelectedKeysChange={this.handleSelectedKeysChange}
                                    dataSource={permissionTableDataSource}
                                    selectedRowKeys={permissionTableSelectedRowKeys}/>)}
              </FormItem>
              <FormItem label=" " colon={false} {...formItemLayout}>
                <Button type="primary" onClick={this.handleConfirmUpdate}>确定</Button>
                <Button style={{marginLeft:20}} onClick={()=>history.back()}>返回</Button>
              </FormItem>
            </Form>
          </div>
        {this.state.permissionModalVisible &&
        <PermissionModal onOk={this.handleAddPermission} onCancel={this.handleHideModal}
                         dataSource={this.state.permissionModalDataSource}
                         selectedRowKeys={this.state.permissionTableSelectedRowKeys}/>}
      </TableLayout>
    )
  }
}

export default MenuEditForm;
