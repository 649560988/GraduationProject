import React , {Component} from 'react';
import { Card, Icon, Form, Select, Input, Button, message} from 'antd';
import styles from './RoleManage.less';
import PermissionTable from './PermisssionTable';
import PermissionModal from './PermissionModal';
import TableLayout from '../../layouts/TableLayout';
import axios from 'axios';

const FormItem = Form.Item;
const {Option, OptGroup} = Select;

@Form.create()
class MenuAddForm extends Component{
  constructor(props) {
    super(props);
    this.parentId = this.props.match.params.parentId;
    this.state = {
      permissionModalVisible: false,
      permissionModalDataSource: [],
      permissionTableDataSource: [],
      permissionTableSelectedRowKeys: [],
    }
  }

  //获取所基于的角色的信息
  fetchParentInfo = () => {
   return axios.get(`/iam-ext/v1/roles/queryWithPermissionsAndLabels/${this.parentId}`);
  }

  //获取所有权限记录
  fetchAllPermissions = () => {
    return axios.get(`/iam-ext/v1/permissions/getAllPermissions`);
  }

  componentDidMount(){
    this.fetchAllPermissions().then(res => {
      const permissionModalDataSource = res.data;
      this.setState({permissionModalDataSource});
    }).catch(err => {
      console.log(err);
      message.error('请求失败');
    });
    if(this.parentId){
      this.fetchParentInfo().then(res => {
        const permissionTableDataSource = res.data.permissions;
        const permissionTableSelectedRowKeys = res.data.permissions.map(item => item.id);
        this.setState({permissionTableDataSource,permissionTableSelectedRowKeys});
      }).catch(err => {
        console.log(err);
        message.error('请求失败');
      })
    }
  }

  //创建按钮点击事件
  handleCreateMenu = (e) =>{
      e.preventDefault();
      // console.log(this.props.form.getFieldValue('permissionList'));
      this.props.form.validateFields((err, values) => {
        if (!err) {
          values.code = 'role/site/custom/'+values.code;
          values.permissionList = values.permissionList.selectedRowKeys;
          const permissions = [];
          values.permissionList.map(item => {
            permissions.push({
              id:item,
            })
          });
          values.permissions = permissions;
          // console.log('Received values of form: ', values);

          axios.post(`/iam-ext/v1/roles/createRoleObject`,{
            name:values.name,
            code:values.code,
            level:'site',
            isModified:1,
            isEnabled:1,
            isEnableForbidden:1,
            isBuiltIn:0,
            isAssignable:0,
            permissions:values.permissions,
          }).then(res => {
            if(res.data === true){
              message.success('添加成功!');
              this.props.history.push('/setting/role-manage');
            }else{
              message.error(res.data);
            }
          }).catch(err => {
            message.error('请求失败，请重试');
            console.log(err);
          })
        }
      });
  }

  //角色名称唯一性验证
  handleNameUniqueCheck = (rule,value,callback) => {
    if(!value){
      callback();
    }else{
      axios.get(`/iam-ext/v1/roles/nameCheck`,{
        params:{
          name:value,
        }
      }).then(res => {
        if(res.data === false){
          callback('角色名称已存在');
        }else{
          callback();
        }
      }).catch(err => {
        console.log('角色名称校验失败',err);
      });
    }
  }

  //角色编码唯一性验证
  handleCodeUniqueCheck = (rule, value, callback) => {
    if(!value){
      callback();
    }else{
      axios.get(`/iam-ext/v1/roles/codeCheck`,{
        params:{
          code:`role/site/custom/${value}`,
        }
      }).then(res => {
        if(res.data === false){
          callback('角色编码已存在');
        }else{
          callback();
        }
      }).catch(err => {
        console.log('角色编码校验失败',err);
      });
    }
  }

  //显示添加权限模态框
  handleShowModal =() => {
    this.setState({permissionModalVisible:true});
  }

  //隐藏添加权限模态框
  handleHideModal = () => {
    this.setState({permissionModalVisible:false});
  }

  //处理已分配权限列表 复选框改变事件
  handleSelectedKeysChange = (selectedRowKeys) => {
    this.handleAddPermission(selectedRowKeys);
  }

  //确认添加权限按钮
  handleAddPermission = (selectedRowKeys) => {
    const {permissionModalDataSource } = this.state;
    const permissionTableDataSource = permissionModalDataSource.filter(item => selectedRowKeys.indexOf(item.id) !== -1);
    this.setState({
      permissionTableDataSource,
      permissionTableSelectedRowKeys:selectedRowKeys,
      permissionModalVisible:false});
  }

  render(){
    const { getFieldDecorator } = this.props.form;
    const { permissionTableDataSource, permissionTableSelectedRowKeys } = this.state;
    const formItemLayout = {
      labelCol: { xs: { span: 24 }, sm: { span: 3 }, },
      wrapperCol: { xs: { span: 24 }, sm: { span: 12, }, },
    };
    return (

        <TableLayout title={`添加角色`} showBackBtn={true} onBackBtnClick={this.props.history.goBack}>
          <div>
            <Form>
              <FormItem label="角色名称" {...formItemLayout}>
                {getFieldDecorator(`name`, {
                  rules: [
                    {required: true, message: '角色名称不能为空', },
                    {max:64,message:'角色名称长度超过限制'},
                    {validator:this.handleNameUniqueCheck},
                  ],
                })(
                  <Input placeholder="角色名称（唯一）" autoComplete='off'/>
                )}
              </FormItem>
              <FormItem label="角色编码" {...formItemLayout}>
                {getFieldDecorator(`code`, {
                  rules: [
                    {required: true, message: '角色编码不能为空', },
                    {max:128,message:'角色编码长度超过限制'},
                    {pattern:/^[a-z]([-a-z0-9]*[a-z0-9])$/,
                      message:'角色编码只能包含小写字母、数字或符号 "-",且以小写字母开头，不能以"-"结尾'},
                    {validator:this.handleCodeUniqueCheck},
                  ],
                })(
                  <Input autoComplete='off' prefix="role/site/custom/" className={styles.codeInput}/>
                )}
              </FormItem>
              <FormItem label="已分配权限" {...formItemLayout}>
                {getFieldDecorator('permissionList', {
                  initialValue: { dataSource:permissionTableDataSource,selectedRowKeys:permissionTableSelectedRowKeys },
                  rules:[]
                })(<PermissionTable showAddModal={this.handleShowModal}
                                    handleSelectedKeysChange={this.handleSelectedKeysChange}
                                    dataSource={permissionTableDataSource}
                                    selectedRowKeys={permissionTableSelectedRowKeys}/>)}
              </FormItem>
              <FormItem label=" " colon={false} {...formItemLayout}>
                <Button type="primary" onClick={this.handleCreateMenu}>创建</Button>
                <Button style={{marginLeft:20}} onClick={()=>history.back()}>返回</Button>
              </FormItem>
            </Form>
          </div>
        {this.state.permissionModalVisible &&
            <PermissionModal onOk={this.handleAddPermission} onCancel={this.handleHideModal}
                              dataSource={this.state.permissionModalDataSource}
                             selectedRowKeys={this.state.permissionTableSelectedRowKeys}/>}
      </TableLayout>
    )
  }
}

export default MenuAddForm;
