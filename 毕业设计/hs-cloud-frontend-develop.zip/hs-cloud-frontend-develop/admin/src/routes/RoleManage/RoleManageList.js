import React, {Component} from 'react'
import {Table, Form, Row, Col, Input, Button, Tooltip, Icon, message, Select} from 'antd'
import styles from './RoleManage.less'
import axios from 'axios'
import TableLayout from '../../layouts/TableLayout'

const FormItem = Form.Item
const Option = Select.Option
const Search = Input.Search
const ButtonGroup = Button.Group
@Form.create()
class RoleManageList extends Component {
  constructor (props) {
    super(props)
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 10,
        total: 0
      }
    }
  }

  fetch = (name, code, isEnabled) => {
    const { pagination } = this.state
    axios.post('/iam-ext/v1/roles/pageRoleInfo?page=' +
      (pagination.current - 1) + '&size=' + pagination.pageSize,
    {'name': name, 'code': code, 'isEnabled': isEnabled}).then(res => {
      const data = res.data.content
      const pagination = {
        current: res.data.number + 1,
        pageSize: res.data.size,
        total: res.data.totalElements
      }
      this.setState({data, pagination})
    }).catch(err => {
      console.log(err)
      message.error('请求失败')
    })
  }

  componentDidMount () {
    this.fetch()
  }

  // 处理表单提交
  handleSearch = (e) => {
    const {form} = this.props
    form.validateFields((err, values) => {
      if (err) return
      const pagination = {
        current: 1,
        pageSize: 10
      }
      if (values.searchType === 'name') {
        this.setState({ pagination }, () => {
          this.fetch(values.keyword, null, null)
        })
      }
      if (values.searchType === 'code') {
        this.setState({ pagination }, () => {
          this.fetch(null, values.keyword, null)
        })
      }
    })
  }

  // 处理重置表单
  handleResetSearchForm = () => {
    this.props.form.resetFields()
    const pagination = {
      current: 1,
      pageSize: 10
    }
    this.setState({pagination}, () => {
      this.fetch()
    })
  }

  // 渲染查询表单
  renderSearchForm = () => {
    const {getFieldDecorator} = this.props.form
    return (
      <Form layout='horizontal'>
        <div>
          <Row type='flex' style={{ justifyContent: 'space-between' }}>
            <Col>
              <Row type='flex'>
                <FormItem
                  wrapperCol={{ span: 24 }}
                >
                  <ButtonGroup>
                    <Button onClick={this.fetch.bind(this, null, null, null)}>全部</Button>
                    <Button onClick={this.fetch.bind(this, null, null, 1)}>启用</Button>
                    <Button onClick={this.fetch.bind(this, null, null, 0)}>禁用</Button>
                  </ButtonGroup>
                </FormItem>
              </Row>
            </Col>
            <Col>
              <Row type='flex'>
                <FormItem
                  wrapperCol={{ span: 24 }}
                >
                  {getFieldDecorator('searchType', {initialValue: 'name', rules: []})(
                    <Select className={'choice'} onChange={this.getType} style={{width: 100}}>
                      <Option value={'name'} key={'name'}>角色名称</Option>
                      <Option value={'code'} key={'code'}>角色编码</Option>
                    </Select>
                  )}
                </FormItem>
                <FormItem
                  style={{marginRight: 10}}
                  wrapperCol={{ span: 24 }}
                >
                  {getFieldDecorator('keyword', {})(
                    <Search style={{height: 32}} placeholder='请输入关键词' onSearch={this.handleSearch} />
                  )}
                </FormItem>
              </Row>
            </Col>
          </Row>
        </div>
      </Form>
    )
  }

  // 跳转到“角色添加”页面
  handleAddRole = () => {
    // this.props.history.push("/setting/menu-add");
    this.props.history.push('/setting/role-manage-add')
  }

  // 渲染角色列表
  renderRoleTable = () => {
    const columns = [
      {
        title: '序号',
        key: 'no',
        render: (text, record, index) => index + 1
      },
      {
        title: '名称',
        key: 'name',
        dataIndex: 'name',
        width: '20%'
      },
      {
        title: '编码',
        key: 'code',
        dataIndex: 'code',
        width: '40%',
        render: (text, record, index) => (
          <Tooltip placement='bottom' title={record.code} overlayClassName={styles.longTooltip}>{record.code}</Tooltip>
        )
      },
      {
        title: '状态',
        key: 'isEnabled',
        dataIndex: 'isEnabled',
        width: '10%',
        render: (text, record, index) => (record.isEnabled === 1 ? '启用' : '停用')
      },
      {
        title: '操作',
        key: 'action',
        width: 170,
        render: (text, record, index) => {
          return (
            <div style={{textAlign: 'right'}}>
              <Tooltip placement='bottom' title='编辑'>
                <Button onClick={() => this.handleEditRole(record.id)} style={{marginRight: 8}}>
                  <Icon type='edit' /></Button>
              </Tooltip>
              <Tooltip placement='bottom' title='基于该角色创建'>
                <Button onClick={() => this.handleAddByPid(record.id)} style={{marginRight: 8}}>
                  <Icon type='link' /></Button>
              </Tooltip>
              {
                record.isEnabled === 1
                  ? <Tooltip placement='bottom' title='停用'>
                    <Button type='danger' onClick={() => this.handleDisableRole(record.id)}>
                      <Icon type='minus-circle-o' /></Button>
                  </Tooltip>
                  : <Tooltip placement='bottom' title='启用'>
                    <Button onClick={() => this.handleEnableRole(record.id)} className={styles.enableBtn}>
                      <Icon type='check-circle-o' /></Button>
                  </Tooltip>
              }
            </div>
          )
        }
      }
    ]
    const pagination = {
      current: this.state.pagination.current,
      pageSize: this.state.pagination.pageSize,
      total: this.state.pagination.total,
      onChange: (current, pageSize) => this.handlePaginationChange(current, pageSize),
      onShowSizeChange: (current, pageSize) => this.handlePaginationChange(1, pageSize),
      showQuickJumper: true,
      showSizeChanger: true
    }
    return (
      <Table className={styles.roleTable} rowKey={record => record.id} dataSource={this.state.data}
        filterBar={false} columns={columns} size='middle' pagination={pagination} />
    )
  }

  // 处理菜单项编辑
  handleEditRole = (id) => {
    this.props.history.push(`/setting/role-manage-edit/${id}`)
  }

  // 处理基于已有菜单创建子菜单
  handleAddByPid = (pid) => {
    this.props.history.push(`/setting/role-manage-add-by-pid/${pid}`)
  }

  // 停用角色
  handleDisableRole =(id) => {
    axios.get(`/iam-ext/v1/roles/disableRole/${id}`).then(res => {
      if (res.data === true) {
        message.success('角色已停用')
        const values = this.props.form.getFieldsValue()
        this.fetch(values.name, values.code, parseInt(values.isEnabled))
      } else {
        message.error('发生错误')
      }
    }).catch(err => {
      message.error('请求失败')
      console.log(err)
    })
  }

  // 启用角色
  handleEnableRole = (id) => {
    axios.get(`/iam-ext/v1/roles/enableRole/${id}`).then(res => {
      if (res.data === true) {
        message.success('角色已启用')
        const values = this.props.form.getFieldsValue()
        this.fetch(values.name, values.code, parseInt(values.isEnabled))
      } else {
        message.error('发生错误')
      }
    }).catch(err => {
      message.error('请求失败')
      console.log(err)
    })
  }

  // 处理分页条件改变
  handlePaginationChange = (current, pageSize) => {
    const pagination = {
      current,
      pageSize
    }
    const { name, code, isEnabled } = this.props.form.getFieldsValue()
    this.setState({pagination}, () => this.fetch(name, code, isEnabled))
  }

  render () {
    return (
      <TableLayout
        title={'角色信息'}
        renderTitleSide={() => (
          <Button type='primary'
            ghost icon='plus'
            onClick={this.handleAddRole}
            style={{border: 0, fontWeight: 'bold'}}
          ><span style={{fontSize: 16, fontFamily: 'heiti'}}>添加</span></Button>
        )}
      >
        {this.renderSearchForm()}
        {this.renderRoleTable()}
      </TableLayout>

    )
  }
}

export default RoleManageList
