import { queryCurrentExt } from '../services/user'

export default {
  namespace: 'user',

  state: {
    list: [],
    currentUser: {}
  },

  effects: {
    * fetchCurrent (_, { call, put }) {
      const user = yield call(queryCurrentExt)

      yield put({
        type: 'saveCurrentUser',
        payload: {
          ...user
        }
      })
      yield put({
        type: 'menu/save',
        payload: user.menuData
      })
    }
  },

  reducers: {
    save (state, action) {
      return {
        ...state,
        list: action.payload
      }
    },
    saveCurrentUser (state, action) {
      return {
        ...state,
        currentUser: action.payload || {}
      }
    },
    changeNotifyCount (state, action) {
      return {
        ...state,
        currentUser: {
          ...state.currentUser,
          notifyCount: action.payload
        }
      }
    }
  }
}
