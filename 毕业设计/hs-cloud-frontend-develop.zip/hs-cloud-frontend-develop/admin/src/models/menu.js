import { isUrl } from '../utils/utils'

const formatter = (data, parentPath = '/', parentAuthority, level = 1) => {
  let menu = data.map(item => {
    const { route, subMenus, name, code, icon, type } = item
    let path = route
    let authority = parentAuthority
    if (!isUrl(path)) {
      if (!path && !!subMenus) {
        path = subMenus[0].route.substr(parentPath.length).split('/')[0]
      } else if (path) {
        if (path[0] === '/') {
          const pathSplited = path.split('/')
          path = pathSplited[pathSplited.length - 1]
        }
      } else {
        // TODO: 没有路由且没有子菜单
      }
    }
    const result = {
      code,
      name,
      type,
      icon,
      path: parentPath + path,
      authority: parentAuthority
    }

    if (subMenus) {
      result.children = formatter(subMenus, `${parentPath}${path}/`, authority, level + 1)
    }
    return result
  })

  return menu
}

export default {
  namespace: 'menu',

  state: {
    isLoading: true,
    menuData: []
  },

  effects: {

  },

  reducers: {
    save (state, action) {
      let menuData = formatter(action.payload)
      return {
        ...state,
        isLoading: false,
        menuData
      }
    }
  }
}
