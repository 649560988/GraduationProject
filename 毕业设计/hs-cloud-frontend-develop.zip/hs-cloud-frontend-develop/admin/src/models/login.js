import { routerRedux } from 'dva/router'
import { setAuthority } from '../utils/authority'
import { reloadAuthorized } from '../utils/Authorized'
import { queryCurrentExt } from '../services/user'

export default {
  namespace: 'login',

  state: {
    username: undefined,
    status: undefined
  },

  effects: {
    * login ({ payload }, { call, put }) {
      const user = yield call(queryCurrentExt)
      yield put({
        type: 'saveCurrentUser',
        payload: {
          ...user
        }
      })
      yield put({
        type: 'menu/save',
        payload: user.menuData
      })

      yield put({
        type: 'changeLoginStatus',
        payload: {
          currentAuthority: 'admin',
          token: payload.token,
          username: 'admin',
          status: true
        }
      })
      reloadAuthorized()
      yield put(routerRedux.replace(payload.redirect || '/'))
    },

    * logout (_, { put, call }) {
      let token = localStorage['antd-pro-token']
      localStorage.clear()
      window.location.href = `${process.env.server}/oauth/logout?access_token=${token}`
    }
  },

  reducers: {
    changeLoginStatus (state, { payload }) {
      // @heineiuo: 登录以后，在localStorage里保存状态
      setAuthority(payload.currentAuthority, payload.token)
      return {
        ...state,
        status: payload.status,
        type: payload.type
      }
    }
  }
}
