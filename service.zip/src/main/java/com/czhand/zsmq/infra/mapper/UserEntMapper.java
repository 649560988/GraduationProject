package com.czhand.zsmq.infra.mapper;

import com.czhand.zsmq.domain.UserEnt;
import com.czhand.zsmq.infra.utils.mapper.BaseMapper;

public interface UserEntMapper extends BaseMapper<UserEnt> {
}