package com.czhand.zsmq.infra.mapper;

import com.czhand.zsmq.domain.OauthRefreshToken;
import com.czhand.zsmq.infra.utils.mapper.BaseMapper;

public interface OauthRefreshTokenMapper extends BaseMapper<OauthRefreshToken> {
}