package com.czhand.zsmq.infra.mapper;

import com.czhand.zsmq.domain.OauthAccessToken;
import com.czhand.zsmq.infra.utils.mapper.BaseMapper;

public interface OauthAccessTokenMapper extends BaseMapper<OauthAccessToken> {
}