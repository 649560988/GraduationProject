//package com.czhand.zsmq.api.dto.ent;
//
//import io.swagger.annotations.ApiModel;
//import io.swagger.annotations.ApiModelProperty;
//
//@ApiModel("高新技术企业DTO")
//public class EntTecDTO {
//
//    @ApiModelProperty("主键id")
//    private Long id;
//
//}
